'use strict';
var theme_contrast = 'true'; // [ false , true ]
var caption_show = 'true'; // [ false , true ]
var preset_theme = 'preset-1'; // [ preset-1 to preset-10 ]
var dark_layout = 'false'; // [ false , true , default ]
var rtl_layout = 'false'; // [ false , true ]
var box_container = 'false'; // [ false , true ]
var version = 'Port-Pro-Panel v3.9.2';
