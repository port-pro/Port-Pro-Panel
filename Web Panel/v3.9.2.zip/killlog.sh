#!/bin/bash
#Port-Pro-Panel Alireza
rm -fr /var/log/auth.log
systemctl restart syslog